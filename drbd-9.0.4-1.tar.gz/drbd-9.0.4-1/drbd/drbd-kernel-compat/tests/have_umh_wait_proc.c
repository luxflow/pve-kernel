#include <linux/kmod.h>

void foo(void)
{
	int bar = UMH_WAIT_PROC;
}
