#include <net/genetlink.h>

struct genl_family family = { .parallel_ops = true, };
